import os
import numpy as np
from scipy.io import wavfile
import re

from psynet.asset import S3Storage
asset_storage = S3Storage("sigspace-bucket", "sigspace-experiment")  # Comment out S3 for local development

# Constants
SAMPLE_RATE = 44100
BASE_STEPS = 16  # matches drum_machine.html internal resolution
STEP_TIME = 0.125  # 125ms per 16th note (120 BPM) - matches drum_machine.html STEP_TIME

def load_sample(filename):
    """Load a WAV file and return its data."""
    sample_rate, data = wavfile.read(f'static/audio/{filename}.wav')
    # Convert stereo to mono if necessary
    if len(data.shape) > 1:
        data = data.mean(axis=1)
    return data

def create_silence(duration):
    """Create a silent audio segment."""
    return np.zeros(int(duration * SAMPLE_RATE))

def generate_pattern_audio(pattern, grid_size, kit_type):
    """Generate audio for a specific pattern."""
    # Load the base samples
    hihat = load_sample('hihat')
    snare = load_sample('snare')
    kick = load_sample('kick')
    
    # Calculate timing based on grid size
    factor = BASE_STEPS / grid_size  # How many 16th notes per grid step
    beat_duration = STEP_TIME * factor  # Duration of each grid step
    
    # Calculate total duration
    total_duration = grid_size * beat_duration
    total_samples = int(total_duration * SAMPLE_RATE)
    
    # Calculate samples per beat
    samples_per_beat = int(beat_duration * SAMPLE_RATE)
    print(f"Grid size: {grid_size}")
    print(f"Factor: {factor}")
    print(f"Beat duration: {beat_duration}")
    print(f"Samples per beat: {samples_per_beat}")
    print(f"Total samples: {total_samples}")
    print(f"Hihat length: {len(hihat)}")
    print(f"Snare length: {len(snare)}")
    print(f"Kick length: {len(kick)}")
    
    # Create empty audio array
    audio = np.zeros(total_samples)
    
    # Parse the pattern and determine which drums to use
    patterns = {}  # Initialize patterns dictionary
    
    if kit_type == 'snare+kick':
        snare_pattern, kick_pattern = pattern.split('_')
        patterns = {'snare': snare_pattern, 'kick': kick_pattern}
    elif kit_type == 'hihat+snare+kick':
        hihat_pattern, snare_pattern, kick_pattern = pattern.split('_')
        patterns = {'hihat': hihat_pattern, 'snare': snare_pattern, 'kick': kick_pattern}
    elif kit_type == 'kick':
        patterns = {'kick': pattern}
    else:
        # Fallback: try to parse the pattern as individual components
        pattern_parts = pattern.split('_')
        if len(pattern_parts) >= 2:
            patterns = {'kick': pattern_parts[0], 'snare': pattern_parts[1]}
        elif len(pattern_parts) == 1:
            patterns = {'kick': pattern_parts[0]}
        else:
            raise ValueError(f"Invalid pattern format: {pattern}")

    
    # Add each beat to the audio
    for i in range(grid_size):
        # Calculate position in the audio array
        pos = int(i * beat_duration * SAMPLE_RATE)
        print(f"Position for beat {i}: {pos}")
        
        # Add each drum hit with full sample length
        if 'hihat' in patterns and i < len(patterns['hihat']) and patterns['hihat'][i] == '1':
            # Add hihat sample, but don't exceed the audio array bounds
            end_pos = min(pos + len(hihat), len(audio))
            audio[pos:end_pos] += hihat[:end_pos - pos]
            
        if 'snare' in patterns and i < len(patterns['snare']) and patterns['snare'][i] == '1':
            # Add snare sample, but don't exceed the audio array bounds
            end_pos = min(pos + len(snare), len(audio))
            audio[pos:end_pos] += snare[:end_pos - pos]
            
        if 'kick' in patterns and i < len(patterns['kick']) and patterns['kick'][i] == '1':
            # Add kick sample, but don't exceed the audio array bounds
            end_pos = min(pos + len(kick), len(audio))
            audio[pos:end_pos] += kick[:end_pos - pos]
    
    # Normalize audio
    if np.max(np.abs(audio)) > 0:
        audio = audio / np.max(np.abs(audio))
    
    return audio

def generate_audio_file(pattern, grid_size, kit_type, output_dir='static/generated_sounds'):
    """Generate a single audio file from a rhythm pattern."""
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    print(f'Output directory: {output_dir}')
    
    # Generate the audio
    audio = generate_pattern_audio(pattern, grid_size, kit_type)
    print(f'Generated audio data shape: {audio.shape}')
    
    # Create filename based on kit type
    if kit_type == 'snare+kick':
        snare_pattern, kick_pattern  = pattern.split('_')
        filename = f"grid{grid_size}_snare{snare_pattern}_kick{kick_pattern}.wav"
    elif kit_type == 'hihat+snare+kick':
        hihat_pattern, snare_pattern, kick_pattern = pattern.split('_')
        filename = f"grid{grid_size}_hihat{hihat_pattern}_snare{snare_pattern}_kick{kick_pattern}.wav"
    
    # Full path for the file
    full_path = os.path.join(output_dir, filename)
    print(f'Full path for audio file: {full_path}')
    
    # Save the audio file
    wavfile.write(full_path, SAMPLE_RATE, (audio * 32767).astype(np.int16))
    print(f'Saved audio file to: {full_path}')
    
    # Return the path relative to the static directory for web access
    return os.path.join('generated_sounds', filename)

def parse_and_generate_audio(director_sound_str):
    """
    Parse a rhythm pattern string like 'hihat_1100_snare_0000_kick_0000' and generate the corresponding audio.
    
    Args:
        director_sound_str (str): Pattern in format 'hihat_[01]+_snare_[01]+_kick_[01]+'
    
    Returns:
        str: Path to the generated audio file
    """
    print(f'Parsing director sound string: {director_sound_str}')
    
    # Remove trailing underscore if present (drum machine outputs with trailing underscore)
    if director_sound_str.endswith('_'):
        director_sound_str = director_sound_str[:-1]
        print(f'Removed trailing underscore: {director_sound_str}')
    
    # Extract patterns
    patterns = {}
    for drum in ['hihat', 'snare', 'kick']:
        pattern_match = re.search(f'{drum}_([01]+)', director_sound_str)
        print(f'DEBUG: Looking for {drum}, pattern_match: {pattern_match}')
        if pattern_match:
            patterns[drum] = pattern_match.group(1)
            print(f'DEBUG: Found {drum} pattern: {pattern_match.group(1)}')
    
    print(f'Extracted patterns: {patterns}')
    
    # Determine grid size from the first pattern
    if not patterns:
        raise ValueError("No valid patterns found in the input string")
    
    grid_size = len(next(iter(patterns.values())))
    print(f'Detected grid size: {grid_size}')
    
    # Determine kit type based on which patterns are present
    if 'hihat' in patterns:
        kit_type = 'hihat+snare+kick'
        pattern = f"{patterns['hihat']}_{patterns['snare']}_{patterns['kick']}"
    elif 'snare' in patterns:
        kit_type = 'snare+kick'
        pattern = f"{patterns['snare']}_{patterns['kick']}"
    else:
        kit_type = 'kick'
        pattern = patterns['kick']
    
    print(f'Using kit type: {kit_type}')
    print(f'Final pattern: {pattern}')
    
    # Generate the audio file
    return generate_audio_file(pattern, grid_size, kit_type)

